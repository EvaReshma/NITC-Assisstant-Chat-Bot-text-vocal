from django.shortcuts import render
from random import randint


# Create your views here.

from django.http import HttpResponse

import numpy as np
import pickle

from chatnow.models import Question, NewQuestion
from difflib import SequenceMatcher as SM
import os
from gtts import gTTS
import nltk


def index(request):
    #createaudio()
    return render(request, 'chatnow/index.html')


def answer(request):
    text = request.POST.get('question', '')
    
      # split into words
    from nltk.tokenize import word_tokenize
    tokens = word_tokenize(text)

# convert to lower case
    tokens = [w.lower() for w in tokens]


# remove punctuation from each word
    import string
    table = str.maketrans('', '', string.punctuation)
    stripped = [w.translate(table) for w in tokens]

# remove remaining tokens that are not alphabetic
    words = [word for word in stripped if word.isalpha()]

# filter out stop words
    from nltk.corpus import stopwords
    stop_words = set(stopwords.words('english'))
    words = [w for w in words if not w in stop_words]

#Stemming 
    #from nltk.stem import PorterStemmer  
    #ps = PorterStemmer() 
    #for i in range(len(words)): 
     # words[i]=ps.stem(words[i])     

    l = []
    l.append(tokens[0])
    l.append(" ")
    for x in words:
        l.append(x)
        l.append(" ")

    question = ''.join(l)
    
    q_list = Question.objects.all()
    reply = ''
    best_score = 0
    fle = 0
    for q in q_list:
        score = SM(None, question, q.question_text).ratio()

        if score > best_score:
            best_score = score
            reply = q.answer_text
            fle = q.id

    audiofile = ""

    if best_score > 0.7:
        answer2 = reply
        audiofile = 'chatnow/audio/ens' + str(fle) + '.mp3'
    else:
        answer2 = "Sorry We dont have that answer now. A notification has been sent to an expert. Check back after some time."
        enter = NewQuestion(question_text=question)
        enter.save()
        audiofile = 'chatnow/audio/sorry.mp3'

        

    context = {'answer2': answer2, 'question': text, 'audiofile': audiofile}
    return render(request, 'chatnow/answer.html', context)


def createaudio():
    q_list = Question.objects.all()
    for q in q_list:
        reply = q.answer_text
        language = 'en'
        myobj = gTTS(text=reply, lang=language, slow=False)
        filename = '"audio\ens"' + '"str(q.id)"' + '".mp3"'
        print(filename)
        myobj.save("chatnow/static/chatnow/audio/ens{}.mp3".format(q.id))

def index2(request):
    return render(request, 'chatnow/index2.html')



def addstr(arg1, arg2):
    return str(arg1) + str(arg2)







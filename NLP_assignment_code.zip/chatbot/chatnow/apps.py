from django.apps import AppConfig


class ChatnowConfig(AppConfig):
    name = 'chatnow'
